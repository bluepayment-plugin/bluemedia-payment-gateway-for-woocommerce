<?php

namespace Isolated\BlueMedia\Ilabs\Ilabs_Plugin\Presentation\Form;

abstract class Abstract_Renderer
{
    public abstract function render();
}
