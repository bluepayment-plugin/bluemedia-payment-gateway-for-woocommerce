<?php

namespace Isolated\BlueMedia\Ilabs\Ilabs_Plugin\Logger;

interface Logger_Interface
{
    public function debug(string $message, string $context = null);
    public function error(string $message, array $args = null, string $context = null);
}
